import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import PrimaryButton from './PrimaryButton';
import { colors } from '../theme/navigationTheme';

export default function DashboardScaffold({
  title,
  subtitle,
  children,
  onBack,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  onBack: () => void;
}) {
  return (
    <View style={styles.root}>
      <LinearGradient colors={[`${colors.primary}25`, `${colors.background}FF`]} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>

        <View style={styles.card}>{children}</View>

        <PrimaryButton title="Retour à l’accueil" variant="outline" onPress={onBack} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingTop: 56, gap: 14 },
  title: { color: colors.text, fontSize: 28, fontWeight: '900' },
  subtitle: { color: colors.mutedText, fontSize: 14 },
  card: {
    marginTop: 10,
    padding: 18,
    borderRadius: 20,
    backgroundColor: 'rgba(18,18,26,0.8)',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
  },
});
