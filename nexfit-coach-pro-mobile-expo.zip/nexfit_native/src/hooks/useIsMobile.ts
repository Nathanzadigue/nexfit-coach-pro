import { useMemo } from 'react';
import { Platform } from 'react-native';

// Dans React Native, l'app tourne sur mobile par définition.
// On garde ce hook pour compatibilité avec du code partagé.
export function useIsMobile() {
  return useMemo(() => Platform.OS === 'android' || Platform.OS === 'ios', []);
}
