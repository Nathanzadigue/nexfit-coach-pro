import { Alert } from 'react-native';

export type ToastArgs = {
  title: string;
  description?: string;
};

// Remplacement simple du toast web (shadcn) par une alerte native.
// Tu peux remplacer plus tard par 'react-native-toast-message' si tu veux un vrai toast.
export function toast({ title, description }: ToastArgs) {
  Alert.alert(title, description);
}
