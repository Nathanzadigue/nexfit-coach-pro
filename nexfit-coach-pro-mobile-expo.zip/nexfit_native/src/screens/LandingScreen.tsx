import React from 'react';
import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import PrimaryButton from '../components/PrimaryButton';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Landing'>;

export default function LandingScreen({ navigation }: Props) {
  return (
    <View style={styles.root}>
      <LinearGradient
        colors={[`${colors.primary}55`, `${colors.accent}22`, `${colors.background}FF`]}
        style={StyleSheet.absoluteFill}
      />
      <ScrollView contentContainerStyle={styles.content}>
        {/* Top bar */}
        <View style={styles.topBar}>
          <View style={styles.logoMark}>
            <Text style={styles.logoMarkText}>NF</Text>
          </View>
          <Text style={styles.logoText}>NexFit</Text>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.h1}>Ton coach, tes progrès, partout.</Text>
          <Text style={styles.subtitle}>
            Programmes, suivi et coaching — pensé mobile, simple, efficace.
          </Text>
          <View style={styles.heroButtons}>
            <PrimaryButton title="Se connecter" onPress={() => navigation.navigate('Login')} />
            <PrimaryButton title="Créer un compte" variant="outline" onPress={() => navigation.navigate('Register')} />
          </View>
        </View>

        {/* Features */}
        <Text style={styles.sectionTitle}>Fonctionnalités</Text>
        <View style={styles.grid}>
          <FeatureCard title="Programmes" desc="Plans d’entraînement clairs, adaptés à ton niveau." emoji="🏋️" />
          <FeatureCard title="Suivi" desc="Historique, objectifs, constance. Tu vois la progression." emoji="📈" />
          <FeatureCard title="Coach" desc="Échanges et recommandations personnalisées." emoji="🧑‍🏫" />
          <FeatureCard title="Nutrition" desc="Rappels & habitudes simples (option)." emoji="🥗" />
        </View>

        {/* Preview */}
        <Text style={[styles.sectionTitle, { marginTop: 18 }]}>Pour qui ?</Text>
        <View style={styles.previewRow}>
          <PreviewPill title="Client" desc="Suivre son programme" onPress={() => navigation.navigate('ClientDashboard')} />
          <PreviewPill title="Coach" desc="Gérer ses élèves" onPress={() => navigation.navigate('CoachDashboard')} />
          <PreviewPill title="Admin" desc="Piloter la plateforme" onPress={() => navigation.navigate('AdminDashboard')} />
        </View>

        {/* CTA */}
        <View style={styles.cta}>
          <Text style={styles.ctaTitle}>Prêt à commencer ?</Text>
          <Text style={styles.ctaDesc}>Tu peux tester l’app en naviguant sur les tableaux de bord.</Text>
          <PrimaryButton title="Aller au tableau de bord client" onPress={() => navigation.navigate('ClientDashboard')} />
        </View>

        <Text style={styles.footer}>© {new Date().getFullYear()} NexFit</Text>
      </ScrollView>
    </View>
  );
}

function FeatureCard({ title, desc, emoji }: { title: string; desc: string; emoji: string }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardEmoji}>{emoji}</Text>
      <Text style={styles.cardTitle}>{title}</Text>
      <Text style={styles.cardDesc}>{desc}</Text>
    </View>
  );
}

function PreviewPill({ title, desc, onPress }: { title: string; desc: string; onPress: () => void }) {
  return (
    <View style={styles.pill}>
      <Text style={styles.pillTitle}>{title}</Text>
      <Text style={styles.pillDesc}>{desc}</Text>
      <View style={{ marginTop: 10 }}>
        <PrimaryButton title="Ouvrir" variant="outline" onPress={onPress} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 36, gap: 16 },
  topBar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 12 },
  logoMark: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoMarkText: { color: colors.text, fontWeight: '900' },
  logoText: { color: colors.text, fontSize: 20, fontWeight: '900' },
  hero: {
    padding: 18,
    borderRadius: 20,
    backgroundColor: 'rgba(18,18,26,0.75)',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 10,
  },
  h1: { color: colors.text, fontSize: 30, fontWeight: '900', lineHeight: 34 },
  subtitle: { color: colors.mutedText, fontSize: 15, lineHeight: 20 },
  heroButtons: { gap: 12, marginTop: 6 },
  sectionTitle: { color: colors.text, fontSize: 18, fontWeight: '800' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  card: {
    width: '48%',
    padding: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(18,18,26,0.8)',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 6,
  },
  cardEmoji: { fontSize: 22 },
  cardTitle: { color: colors.text, fontSize: 15, fontWeight: '800' },
  cardDesc: { color: colors.mutedText, fontSize: 13, lineHeight: 18 },
  previewRow: { gap: 12 },
  pill: {
    padding: 16,
    borderRadius: 20,
    backgroundColor: 'rgba(18,18,26,0.8)',
    borderWidth: 1,
    borderColor: colors.border,
  },
  pillTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  pillDesc: { color: colors.mutedText, marginTop: 4 },
  cta: {
    marginTop: 10,
    padding: 18,
    borderRadius: 22,
    backgroundColor: 'rgba(124,58,237,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(124,58,237,0.35)',
    gap: 10,
  },
  ctaTitle: { color: colors.text, fontSize: 18, fontWeight: '900' },
  ctaDesc: { color: colors.mutedText, marginBottom: 4 },
  footer: { color: colors.mutedText, textAlign: 'center', marginTop: 10 },
});
