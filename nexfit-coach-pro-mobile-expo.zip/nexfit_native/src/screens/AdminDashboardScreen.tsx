import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import DashboardScaffold from '../components/DashboardScaffold';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'AdminDashboard'>;

export default function AdminDashboardScreen({ navigation }: Props) {
  return (
    <DashboardScaffold
      title="Tableau de bord admin"
      subtitle="KPI, gestion utilisateurs, contenus, paiements (à brancher)."
      onBack={() => navigation.replace('Landing')}
    >
      <CardLine title="Utilisateurs" value="1 284" />
      <CardLine title="Coachs" value="64" />
      <CardLine title="Abonnements actifs" value="312" />

      <Text style={styles.note}>
        Sur mobile, l’admin est souvent un écran "lecture" (KPI) + quelques actions clés.
      </Text>
    </DashboardScaffold>
  );
}

function CardLine({ title, value }: { title: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.k}>{title}</Text>
      <Text style={styles.v}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  k: { color: colors.mutedText, flex: 1 },
  v: { color: colors.text, fontWeight: '800' },
  note: { color: colors.mutedText, fontSize: 12, lineHeight: 16, marginTop: 6 },
});
