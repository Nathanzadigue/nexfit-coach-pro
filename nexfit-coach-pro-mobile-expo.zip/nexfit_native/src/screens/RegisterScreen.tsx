import React, { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import PrimaryButton from '../components/PrimaryButton';
import TextField from '../components/TextField';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Register'>;

type UserType = 'client' | 'coach';

export default function RegisterScreen({ navigation }: Props) {
  const [userType, setUserType] = useState<UserType>('client');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const passwordRequirements = useMemo(
    () => [
      { label: 'Au moins 8 caractères', met: password.length >= 8 },
      { label: 'Une majuscule', met: /[A-Z]/.test(password) },
      { label: 'Un chiffre', met: /[0-9]/.test(password) },
    ],
    [password]
  );

  const onSubmit = () => {
    // TODO: brancher la création de compte
    navigation.replace(userType === 'coach' ? 'CoachDashboard' : 'ClientDashboard');
  };

  return (
    <View style={styles.root}>
      <LinearGradient colors={[`${colors.accent}33`, `${colors.background}FF`]} style={StyleSheet.absoluteFill} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>Créer un compte</Text>
          <Text style={styles.subtitle}>Rejoins NexFit et démarre ta transformation.</Text>

          <View style={styles.card}>
            <Text style={styles.sectionLabel}>Je suis…</Text>
            <View style={styles.row}>
              <RoleButton
                active={userType === 'client'}
                title="Client"
                desc="Je cherche un coach"
                emoji="🏋️"
                onPress={() => setUserType('client')}
              />
              <RoleButton
                active={userType === 'coach'}
                title="Coach"
                desc="Je propose mes services"
                emoji="🧑‍🏫"
                onPress={() => setUserType('coach')}
              />
            </View>

            <View style={{ height: 8 }} />
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <TextField label="Prénom" placeholder="Jean" value={firstName} onChangeText={setFirstName} />
              </View>
              <View style={{ flex: 1 }}>
                <TextField label="Nom" placeholder="Dupont" value={lastName} onChangeText={setLastName} />
              </View>
            </View>

            <TextField label="Email" placeholder="vous@exemple.com" value={email} onChangeText={setEmail} keyboardType="email-address" />
            <TextField label="Mot de passe" placeholder="••••••••" value={password} onChangeText={setPassword} secureTextEntry />

            <View style={{ gap: 6, marginTop: 2 }}>
              {passwordRequirements.map((r) => (
                <Text key={r.label} style={[styles.req, r.met ? styles.reqOk : styles.reqKo]}>
                  {r.met ? '✅ ' : '⬜️ '}
                  {r.label}
                </Text>
              ))}
            </View>

            <View style={{ height: 10 }} />
            <PrimaryButton title="Créer mon compte" onPress={onSubmit} />
            <View style={{ height: 10 }} />
            <PrimaryButton title="J’ai déjà un compte" variant="outline" onPress={() => navigation.navigate('Login')} />

            <Text style={styles.terms}>
              En créant un compte, tu acceptes les CGU et la politique de confidentialité (à brancher).
            </Text>
          </View>

          <PrimaryButton title="Retour" variant="outline" onPress={() => navigation.goBack()} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

function RoleButton({
  active,
  title,
  desc,
  emoji,
  onPress,
}: {
  active: boolean;
  title: string;
  desc: string;
  emoji: string;
  onPress: () => void;
}) {
  return (
    <View style={[styles.role, active && styles.roleActive]}>
      <Text style={styles.roleEmoji}>{emoji}</Text>
      <Text style={styles.roleTitle}>{title}</Text>
      <Text style={styles.roleDesc}>{desc}</Text>
      <View style={{ marginTop: 10 }}>
        <PrimaryButton title={active ? 'Sélectionné' : 'Choisir'} variant="outline" onPress={onPress} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: { padding: 20, paddingTop: 56, gap: 14 },
  title: { color: colors.text, fontSize: 30, fontWeight: '900' },
  subtitle: { color: colors.mutedText, fontSize: 15 },
  card: {
    marginTop: 10,
    padding: 18,
    borderRadius: 20,
    backgroundColor: 'rgba(18,18,26,0.8)',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 14,
  },
  sectionLabel: { color: colors.text, fontWeight: '800' },
  row: { flexDirection: 'row', gap: 12 },
  role: {
    flex: 1,
    padding: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(11,11,16,0.6)',
  },
  roleActive: {
    borderColor: 'rgba(124,58,237,0.7)',
    backgroundColor: 'rgba(124,58,237,0.12)',
  },
  roleEmoji: { fontSize: 20 },
  roleTitle: { color: colors.text, fontWeight: '900', marginTop: 6 },
  roleDesc: { color: colors.mutedText, fontSize: 12, marginTop: 2 },
  req: { fontSize: 12 },
  reqOk: { color: '#34d399' },
  reqKo: { color: colors.mutedText },
  terms: { color: colors.mutedText, fontSize: 12, lineHeight: 16, marginTop: 6 },
});
