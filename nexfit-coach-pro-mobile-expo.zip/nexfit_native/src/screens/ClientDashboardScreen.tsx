import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import DashboardScaffold from '../components/DashboardScaffold';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'ClientDashboard'>;

export default function ClientDashboardScreen({ navigation }: Props) {
  return (
    <DashboardScaffold
      title="Tableau de bord client"
      subtitle="Ici tu retrouveras tes séances, ton suivi et tes objectifs."
      onBack={() => navigation.replace('Landing')}
    >
      <CardLine title="Séance du jour" value="Full body – 45 min" />
      <CardLine title="Objectif hebdo" value="3 / 4 séances" />
      <CardLine title="Prochain check-in" value="Dimanche" />

      <Text style={styles.note}>
        Pour aller plus loin: branche l’API + auth, puis remplace ces blocs par tes données réelles.
      </Text>
    </DashboardScaffold>
  );
}

function CardLine({ title, value }: { title: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.k}>{title}</Text>
      <Text style={styles.v}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  k: { color: colors.mutedText, flex: 1 },
  v: { color: colors.text, fontWeight: '800' },
  note: { color: colors.mutedText, fontSize: 12, lineHeight: 16, marginTop: 6 },
});
