import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import PrimaryButton from '../components/PrimaryButton';
import TextField from '../components/TextField';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const onSubmit = () => {
    // TODO: brancher ton auth
    // pour la démo: redirige vers ClientDashboard
    navigation.replace('ClientDashboard');
  };

  return (
    <View style={styles.root}>
      <LinearGradient colors={[`${colors.primary}40`, `${colors.background}FF`]} style={StyleSheet.absoluteFill} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>Bon retour !</Text>
          <Text style={styles.subtitle}>Connecte-toi pour accéder à ton espace.</Text>

          <View style={styles.card}>
            <TextField label="Email" placeholder="vous@exemple.com" value={email} onChangeText={setEmail} keyboardType="email-address" />
            <TextField label="Mot de passe" placeholder="••••••••" value={password} onChangeText={setPassword} secureTextEntry />

            <View style={{ height: 12 }} />
            <PrimaryButton title="Se connecter" onPress={onSubmit} />
            <View style={{ height: 10 }} />
            <PrimaryButton title="Créer un compte" variant="outline" onPress={() => navigation.navigate('Register')} />

            <Text style={styles.hint}>
              Astuce: tu peux aussi ouvrir directement un tableau de bord depuis l’accueil.
            </Text>
          </View>

          <PrimaryButton title="Retour" variant="outline" onPress={() => navigation.goBack()} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: { padding: 20, paddingTop: 56, gap: 14 },
  title: { color: colors.text, fontSize: 30, fontWeight: '900' },
  subtitle: { color: colors.mutedText, fontSize: 15 },
  card: {
    marginTop: 10,
    padding: 18,
    borderRadius: 20,
    backgroundColor: 'rgba(18,18,26,0.8)',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 14,
  },
  hint: { color: colors.mutedText, marginTop: 12, fontSize: 12, lineHeight: 16 },
});
