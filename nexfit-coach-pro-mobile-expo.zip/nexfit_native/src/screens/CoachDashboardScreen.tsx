import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import DashboardScaffold from '../components/DashboardScaffold';
import { colors } from '../theme/navigationTheme';
import type { RootStackParamList } from '../navigation/RootNavigator';

type Props = NativeStackScreenProps<RootStackParamList, 'CoachDashboard'>;

export default function CoachDashboardScreen({ navigation }: Props) {
  return (
    <DashboardScaffold
      title="Tableau de bord coach"
      subtitle="Liste élèves, programmes, check-ins, messages (à brancher)."
      onBack={() => navigation.replace('Landing')}
    >
      <CardLine title="Élèves actifs" value="12" />
      <CardLine title="Check-ins aujourd’hui" value="3" />
      <CardLine title="Programmes à valider" value="2" />

      <Text style={styles.note}>
        Ici, l’étape suivante est de connecter tes vraies entités: clients, programmes, planning et messagerie.
      </Text>
    </DashboardScaffold>
  );
}

function CardLine({ title, value }: { title: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.k}>{title}</Text>
      <Text style={styles.v}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  k: { color: colors.mutedText, flex: 1 },
  v: { color: colors.text, fontWeight: '800' },
  note: { color: colors.mutedText, fontSize: 12, lineHeight: 16, marginTop: 6 },
});
