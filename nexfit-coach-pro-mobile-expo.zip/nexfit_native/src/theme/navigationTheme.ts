import { DarkTheme, type Theme } from '@react-navigation/native';

export const colors = {
  background: '#0b0b10',
  card: '#12121a',
  text: '#ffffff',
  mutedText: '#a1a1aa',
  border: '#27272a',
  primary: '#7c3aed',
  accent: '#22d3ee',
  danger: '#ef4444',
};

export const appNavigationTheme: Theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.background,
    card: colors.card,
    text: colors.text,
    border: colors.border,
    primary: colors.primary,
    notification: colors.accent,
  },
};
