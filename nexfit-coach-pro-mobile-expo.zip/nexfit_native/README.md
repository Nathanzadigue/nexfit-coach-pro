# NexFit – React Native (Expo)

Ce dossier est une **portabilité mobile** de ton projet React (Vite + Tailwind + shadcn/ui).

✅ Ce qui est livré ici :
- Un projet **Expo + React Native + TypeScript**
- Navigation (Stack) : Landing / Login / Register / Dashboards (Client, Coach, Admin)
- Composants de base (bouton, champs, scaffold)

## Lancer en local

```bash
npm install
npm run start
```

Puis scanne le QR Code avec **Expo Go** (iOS/Android).

## Notes importantes

- Les composants **shadcn/ui / Radix / Tailwind** du projet web ne sont pas réutilisables tels quels en React Native.
- L'UI a été **réécrite** en RN (StyleSheet) avec une apparence proche.
- Les écrans Dashboard sont des **placeholders** : à brancher sur ton auth + API.

## Étape suivante (pour une vraie migration)

1) Me donner l'API / auth (endpoints, tokens, etc.)
2) Migrer tes vraies entités : programmes, séances, clients, messages
3) Remplacer les placeholders des dashboards par tes données
4) Ajouter persistance : AsyncStorage / SecureStore
