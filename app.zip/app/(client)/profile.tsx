import { View, Text, TextInput, Pressable } from "react-native";
import { useEffect, useState } from "react";
import { useAuth } from "@/src/store/AuthContext";
import { getUserProfile, updateUserProfile } from "@/src/services/userService";

export default function ProfileScreen() {
  const { user, signOut } = useAuth();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [role, setRole] = useState<"client" | "coach">("client");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    getUserProfile(user.uid).then((profile) => {
      if (profile) {
        setFirstName(profile.firstName);
        setLastName(profile.lastName);
        setRole(profile.role);
      }
      setLoading(false);
    });
  }, [user]);

  if (!user) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Vous devez être connecté</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Chargement…</Text>
      </View>
    );
  }

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, marginBottom: 16 }}>
        Mon profil
      </Text>

      <TextInput
        placeholder="Prénom"
        value={firstName}
        onChangeText={setFirstName}
        style={{ borderWidth: 1, padding: 10, marginBottom: 12 }}
      />

      <TextInput
        placeholder="Nom"
        value={lastName}
        onChangeText={setLastName}
        style={{ borderWidth: 1, padding: 10, marginBottom: 12 }}
      />

      <Text style={{ marginBottom: 8 }}>Rôle</Text>

      <Pressable
        onPress={() => setRole("client")}
        style={{
          padding: 10,
          backgroundColor: role === "client" ? "#000" : "#ccc",
          marginBottom: 8,
        }}
      >
        <Text style={{ color: "#fff" }}>Client</Text>
      </Pressable>

      <Pressable
        onPress={() => setRole("coach")}
        style={{
          padding: 10,
          backgroundColor: role === "coach" ? "#000" : "#ccc",
          marginBottom: 16,
        }}
      >
        <Text style={{ color: "#fff" }}>Coach</Text>
      </Pressable>

      <Pressable
        onPress={async () => {
          await updateUserProfile(user.uid, {
            firstName,
            lastName,
            role,
          });
        }}
        style={{ padding: 12, backgroundColor: "#000", marginBottom: 12 }}
      >
        <Text style={{ color: "#fff", textAlign: "center" }}>
          Enregistrer
        </Text>
      </Pressable>

      <Pressable onPress={signOut}>
        <Text style={{ color: "red", textAlign: "center" }}>
          Se déconnecter
        </Text>
      </Pressable>
    </View>
  );
}
