import { Tabs } from "expo-router";

export default function ClientLayout() {
  return (
    <Tabs initialRouteName="index">
      <Tabs.Screen
        name="index"
        options={{ title: "Accueil" }}
      />

      <Tabs.Screen
        name="bookings"
        options={{ title: "Réservations" }}
      />

      <Tabs.Screen
        name="profile"
        options={{ title: "Profil" }}
      />

      <Tabs.Screen
        name="coaches"
        options={{ title: "Coachs" }}
      />

      {/* Écran détail coach : caché */}
      <Tabs.Screen
        name="coaches/[id]"
        options={{ href: null }}
      />
    </Tabs>
  );
}
