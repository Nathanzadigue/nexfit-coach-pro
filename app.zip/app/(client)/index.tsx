import { View, Text } from "react-native";

export default function HomeClient() {
  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22 }}>Bienvenue sur NexFit</Text>
      <Text>Trouvez et réservez votre coach sportif</Text>
    </View>
  );
}
