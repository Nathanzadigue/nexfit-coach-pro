import { View, Text, Pressable, Alert } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";

import { coachProfiles, users, availabilities } from "@/src/data";
import { useBookings } from "@/src/store/BookingContext";
import { useAuth } from "@/src/store/AuthContext";
import { getUserProfile } from "@/src/services/userService";

export default function CoachDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();

  const { user } = useAuth();
  const { bookings, createBooking } = useBookings();

  const [selectedAvailabilityId, setSelectedAvailabilityId] =
    useState<string | null>(null);

  const [profileComplete, setProfileComplete] =
    useState<boolean | null>(null);

  // 🔹 Vérifier si le profil est complet
  useEffect(() => {
    if (!user) {
      setProfileComplete(false);
      return;
    }

    getUserProfile(user.uid).then((profile) => {
      if (!profile) {
        setProfileComplete(false);
        return;
      }

      const isComplete =
        profile.firstName.trim() !== "" &&
        profile.lastName.trim() !== "";

      setProfileComplete(isComplete);
    });
  }, [user]);

  // 🔹 Coach + user associé (mock pour l’instant)
  const coach = coachProfiles.find((c) => c.id === id);
  const coachUser = coach
    ? users.find((u) => u.id === coach.userId)
    : null;

  if (!coach || !coachUser) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Coach introuvable</Text>
      </View>
    );
  }

  // 🔹 Disponibilités NON réservées
  const coachAvailabilities = availabilities.filter((a) => {
    const isSameCoach = a.coachId === coach.id;

    const isAlreadyBooked = bookings.some(
      (b) =>
        b.coachId === coach.id &&
        b.date === a.date &&
        b.status !== "cancelled"
    );

    return isSameCoach && !isAlreadyBooked;
  });

  return (
    <View style={{ padding: 20 }}>
      {/* Infos coach */}
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        {coachUser.firstName} {coachUser.lastName}
      </Text>

      <Text>{coach.specialty}</Text>
      <Text>{coach.city}</Text>

      <Text style={{ marginVertical: 10 }}>
        {coach.bio}
      </Text>

      <Text>{coach.pricePerSession} € / séance</Text>

      {/* Créneaux */}
      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Choisir un créneau
      </Text>

      {coachAvailabilities.length === 0 ? (
        <Text>Aucune disponibilité</Text>
      ) : (
        coachAvailabilities.map((a) => {
          const selected = a.id === selectedAvailabilityId;

          return (
            <Pressable
              key={a.id}
              onPress={() =>
                setSelectedAvailabilityId((prev) =>
                  prev === a.id ? null : a.id
                )
              }
              style={{
                padding: 12,
                marginTop: 8,
                borderRadius: 4,
                backgroundColor: selected ? "#000" : "#eee",
              }}
            >
              <Text style={{ color: selected ? "#fff" : "#000" }}>
                {a.date} — {a.startTime} à {a.endTime}
              </Text>
            </Pressable>
          );
        })
      )}

      {/* Réserver */}
      <Pressable
        disabled={!selectedAvailabilityId}
        style={{
          marginTop: 24,
          padding: 12,
          borderRadius: 4,
          backgroundColor: selectedAvailabilityId ? "#000" : "#999",
        }}
        onPress={() => {
          // 🔒 Auth obligatoire
          if (!user) {
            router.push("/auth");
            return;
          }

          // 🔒 Profil complet obligatoire
          if (!profileComplete) {
            Alert.alert(
              "Profil incomplet",
              "Veuillez compléter votre prénom et nom avant de réserver."
            );
            router.push("/profile");
            return;
          }

          const slot = coachAvailabilities.find(
            (a) => a.id === selectedAvailabilityId
          );
          if (!slot) return;

          createBooking(coach.id, user.uid, slot.date);
          setSelectedAvailabilityId(null);
          router.push("/bookings");
        }}
      >
        <Text style={{ color: "#fff", textAlign: "center" }}>
          Réserver une séance
        </Text>
      </Pressable>
    </View>
  );
}
