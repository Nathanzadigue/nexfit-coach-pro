import { View, Text, Pressable } from "react-native";
import { Link } from "expo-router";
import { coachProfiles } from "@/src/data";

export default function CoachList() {
  return (
    <View style={{ padding: 20 }}>
      {coachProfiles.map((coach) => (
        <Link
          key={coach.id}
          href={`/coaches/${coach.id}`}
          asChild
        >
          <Pressable style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 18 }}>
              {coach.specialty} – {coach.city}
            </Text>
            <Text>{coach.pricePerSession} € / séance</Text>
          </Pressable>
        </Link>
      ))}
    </View>
  );
}
