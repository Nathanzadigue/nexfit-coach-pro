import { View, Text } from "react-native";
import { useBookings } from "@/src/store/BookingContext";

export default function Bookings() {
  const { bookings } = useBookings();

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 20 }}>Mes réservations</Text>

      {bookings.length === 0 ? (
        <Text>Aucune réservation</Text>
      ) : (
        bookings.map((b) => (
          <Text key={b.id}>
            Coach {b.coachId} – {b.status} – {b.date}
          </Text>
        ))
      )}
    </View>
  );
}
