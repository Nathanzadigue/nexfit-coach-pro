import { View, Text, TextInput, Pressable } from "react-native";
import { useState } from "react";
import { useAuth } from "@/src/store/AuthContext";
import { useRouter } from "expo-router";

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    if (!isValidEmail(email)) {
      setError("Veuillez entrer un email valide");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit contenir au moins 6 caractères");
      return;
    }

    try {
      await signIn(email, password);
      router.replace("/");
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleSignup = async () => {
    if (!isValidEmail(email)) {
      setError("Veuillez entrer un email valide");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit contenir au moins 6 caractères");
      return;
    }

    try {
      await signUp(email, password);
      router.replace("/");
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, marginBottom: 16 }}>
        Connexion / Inscription
      </Text>

      {/* EMAIL */}
      <TextInput
        placeholder="Email"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
        style={{
          borderWidth: 1,
          padding: 10,
          marginBottom: 12,
        }}
      />

      {/* MOT DE PASSE */}
      <TextInput
        placeholder="Mot de passe (min. 6 caractères)"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={{
          borderWidth: 1,
          padding: 10,
          marginBottom: 12,
        }}
      />

      {error && (
        <Text style={{ color: "red", marginBottom: 12 }}>
          {error}
        </Text>
      )}

      <Pressable
        onPress={handleLogin}
        style={{
          padding: 12,
          backgroundColor: "#000",
          marginBottom: 8,
        }}
      >
        <Text style={{ color: "#fff", textAlign: "center" }}>
          Se connecter
        </Text>
      </Pressable>

      <Pressable
        onPress={handleSignup}
        style={{
          padding: 12,
          backgroundColor: "#555",
        }}
      >
        <Text style={{ color: "#fff", textAlign: "center" }}>
          S’inscrire
        </Text>
      </Pressable>
    </View>
  );
}
