import { Stack } from "expo-router";
import { BookingProvider } from "@/src/store/BookingContext";
import { AuthProvider } from "@/src/store/AuthContext";

export default function RootLayout() {
  return (
    <AuthProvider>
      <BookingProvider>
        <Stack screenOptions={{ headerShown: false }} />
      </BookingProvider>
    </AuthProvider>
  );
}
