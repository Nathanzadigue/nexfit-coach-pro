import { ClientProfile } from "../types";

export const clientProfiles: ClientProfile[] = [
  {
    id: "cl1",
    userId: "u1",
    goals: "Perte de poids et remise en forme",
    city: "Paris",
  },
];
