import { Booking } from "../types";

export const bookings: Booking[] = [];
