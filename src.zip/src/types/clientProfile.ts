// src/types/clientProfile.ts
export type ClientProfile = {
  id: string;
  userId: string;      // référence User.id
  goals: string;
  city: string;
};
