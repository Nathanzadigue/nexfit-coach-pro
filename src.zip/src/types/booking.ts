bookings/{bookingId}
{
  coachId: string
  clientId: string
  date: "YYYY-MM-DD"
  status: "pending" | "accepted" | "refused" | "cancelled"
  createdAt: timestamp
}
