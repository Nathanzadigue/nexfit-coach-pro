availabilities/{availabilityId}
{
  coachId: string
  date: "YYYY-MM-DD"
  startTime: "HH:mm"
  endTime: "HH:mm"
}
