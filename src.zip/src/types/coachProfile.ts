coachProfiles/{coachId}
{
  userId: string
  bio: string
  specialty: string
  pricePerSession: number
  city: string
  isActive: boolean
}
