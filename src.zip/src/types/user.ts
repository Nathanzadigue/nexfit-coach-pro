users/{userId}
{
  email: string
  firstName: string
  lastName: string
  role: "client" | "coach"
  createdAt: timestamp
}
